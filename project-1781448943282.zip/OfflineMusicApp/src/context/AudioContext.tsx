import React, { createContext, useState, useContext, useEffect, useRef } from "react";
import { Audio, InterruptionModeAndroid, InterruptionModeIOS } from "expo-av";
import * as FileSystem from "expo-file-system/legacy";
import AsyncStorage from "@react-native-async-storage/async-storage";

export interface Song {
  id: string;
  uri: string;
  name: string;
  isFavorite: boolean;
}

export interface CustomPlaylist {
  id: string;
  name: string;
  songIds: string[];
}

type RepeatMode = "none" | "one" | "all";

interface AudioContextType {
  playlist: Song[];
  customPlaylists: CustomPlaylist[];
  currentSong: Song | null;
  isPlaying: boolean;
  playbackStatus: any;
  isShuffle: boolean;
  repeatMode: RepeatMode;
  importSongs: (assets: any[]) => Promise<void>;
  playSong: (song: Song, customQueue?: Song[]) => Promise<void>;
  pauseSong: () => Promise<void>;
  resumeSong: () => Promise<void>;
  nextSong: () => Promise<void>;
  previousSong: () => Promise<void>;
  deleteSong: (id: string) => Promise<void>;
  deleteSongsBulk: (ids: string[]) => Promise<void>;
  toggleFavorite: (id: string) => Promise<void>;
  setFavoritesBulk: (ids: string[], status: boolean) => Promise<void>;
  toggleShuffle: () => void;
  toggleRepeat: () => void;
  seek: (position: number) => Promise<void>;
  createCustomPlaylist: (name: string, songIds: string[]) => Promise<void>;
  deleteCustomPlaylist: (id: string) => Promise<void>;
  reorderSongs: (oldIndex: number, newIndex: number) => Promise<void>;
  updatePlaylistOrder: (newPlaylist: Song[]) => Promise<void>;
}

const AudioContext = createContext<AudioContextType | undefined>(undefined);

export const AudioProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [playlist, setPlaylist] = useState<Song[]>([]);
  const [customPlaylists, setCustomPlaylists] = useState<CustomPlaylist[]>([]);
  const [currentSong, setCurrentSong] = useState<Song | null>(null);
  const [sound, setSound] = useState<Audio.Sound | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [playbackStatus, setPlaybackStatus] = useState<any>(null);
  const [isShuffle, setIsShuffle] = useState(false);
  const [repeatMode, setRepeatMode] = useState<RepeatMode>("none");
  const [currentQueue, setCurrentQueue] = useState<Song[]>([]);

  // Use refs to avoid closure stale state in status updates
  const stateRef = useRef({ repeatMode, isShuffle, currentQueue, playlist, currentSong });
  useEffect(() => {
    stateRef.current = { repeatMode, isShuffle, currentQueue, playlist, currentSong };
  }, [repeatMode, isShuffle, currentQueue, playlist, currentSong]);

  useEffect(() => {
    loadData();
    setupAudio();
    return () => {
      if (sound) {
        sound.unloadAsync();
      }
    };
  }, [sound]); 

  useEffect(() => {
    // Initial mount only
    loadData();
    setupAudio();
    return () => {};
  }, []);

  const setupAudio = async () => {
    try {
      await Audio.setAudioModeAsync({
        allowsRecordingIOS: false,
        staysActiveInBackground: true,
        interruptionModeIOS: InterruptionModeIOS.DoNotMix,
        playsInSilentModeIOS: true,
        shouldDuckAndroid: true,
        interruptionModeAndroid: InterruptionModeAndroid.DoNotMix,
        playThroughEarpieceAndroid: false,
      });
    } catch (error) {
      console.log("Error setting up audio mode:", error);
    }
  };

  const loadData = async () => {
    try {
      const savedPlaylist = await AsyncStorage.getItem("playlist");
      if (savedPlaylist) {
        setPlaylist(JSON.parse(savedPlaylist));
      }
      const savedCustomPlaylists = await AsyncStorage.getItem("customPlaylists");
      if (savedCustomPlaylists) {
        setCustomPlaylists(JSON.parse(savedCustomPlaylists));
      }
    } catch (error) {
      console.error("Failed to load data", error);
    }
  };

  const savePlaylist = async (newPlaylist: Song[]) => {
    try {
      await AsyncStorage.setItem("playlist", JSON.stringify(newPlaylist));
    } catch (error) {
      console.error("Failed to save playlist", error);
    }
  };

  const saveCustomPlaylists = async (newPlaylists: CustomPlaylist[]) => {
    try {
      await AsyncStorage.setItem("customPlaylists", JSON.stringify(newPlaylists));
    } catch (error) {
      console.error("Failed to save custom playlists", error);
    }
  };

  const importSongs = async (assets: any[]) => {
    try {
      const newSongs: Song[] = [];
      for (const asset of assets) {
        const fileName = `${Date.now()}_${asset.name}`;
        const destinationUri = `${FileSystem.documentDirectory}${fileName}`;
        
        await FileSystem.copyAsync({
          from: asset.uri,
          to: destinationUri,
        });

        newSongs.push({
          id: Math.random().toString(36).substr(2, 9),
          uri: destinationUri,
          name: asset.name,
          isFavorite: false,
        });
      }

      const updatedPlaylist = [...playlist, ...newSongs];
      setPlaylist(updatedPlaylist);
      await savePlaylist(updatedPlaylist);
    } catch (error) {
      console.error("Error importing songs", error);
    }
  };

  const internalNextSong = () => {
    const { isShuffle, currentQueue, playlist, currentSong, repeatMode } = stateRef.current;
    const activeQueue = currentQueue.length > 0 ? currentQueue : playlist;
    if (activeQueue.length === 0) return;
    
    let nextIndex = 0;
    if (isShuffle) {
      nextIndex = Math.floor(Math.random() * activeQueue.length);
    } else {
      const currentIndex = activeQueue.findIndex(s => s.id === currentSong?.id);
      nextIndex = (currentIndex + 1);
      if (nextIndex >= activeQueue.length) {
        if (repeatMode === "all") {
          nextIndex = 0;
        } else {
          return;
        }
      }
    }
    playSong(activeQueue[nextIndex]);
  };

  const onPlaybackStatusUpdate = (status: any) => {
    setPlaybackStatus(status);
    setIsPlaying(status.isPlaying);
    if (status.didJustFinish) {
      const { repeatMode } = stateRef.current;
      if (repeatMode === "one") {
        sound?.replayAsync();
      } else {
        internalNextSong();
      }
    }
  };

  const playSong = async (song: Song, customQueue?: Song[]) => {
    try {
      if (customQueue) {
        setCurrentQueue(customQueue);
      } else if (currentQueue.length === 0 || !currentQueue.find(s => s.id === song.id)) {
        setCurrentQueue(playlist);
      }

      if (sound) {
        await sound.unloadAsync();
      }

      const { sound: newSound } = await Audio.Sound.createAsync(
        { uri: song.uri },
        { shouldPlay: true, progressUpdateIntervalMillis: 500 },
        onPlaybackStatusUpdate
      );

      setSound(newSound);
      setCurrentSong(song);
      setIsPlaying(true);
    } catch (error) {
      console.error("Error playing song", error);
    }
  };

  const pauseSong = async () => {
    if (sound) {
      await sound.pauseAsync();
      setIsPlaying(false);
    }
  };

  const resumeSong = async () => {
    if (sound) {
      await sound.playAsync();
      setIsPlaying(true);
    }
  };

  const nextSong = async () => {
    internalNextSong();
  };

  const previousSong = async () => {
    const activeQueue = currentQueue.length > 0 ? currentQueue : playlist;
    if (activeQueue.length === 0) return;
    const currentIndex = activeQueue.findIndex(s => s.id === currentSong?.id);
    const prevIndex = (currentIndex - 1 + activeQueue.length) % activeQueue.length;
    await playSong(activeQueue[prevIndex]);
  };

  const deleteSong = async (id: string) => {
    const songToDelete = playlist.find(s => s.id === id);
    if (songToDelete) {
      try {
        await FileSystem.deleteAsync(songToDelete.uri, { idempotent: true });
        const updatedPlaylist = playlist.filter(s => s.id !== id);
        setPlaylist(updatedPlaylist);
        await savePlaylist(updatedPlaylist);
        
        const updatedCustom = customPlaylists.map(cp => ({
          ...cp,
          songIds: cp.songIds.filter(sid => sid !== id)
        }));
        setCustomPlaylists(updatedCustom);
        await saveCustomPlaylists(updatedCustom);

        if (currentSong?.id === id) {
          if (sound) await sound.unloadAsync();
          setCurrentSong(null);
          setIsPlaying(false);
        }
      } catch (error) {
        console.error("Error deleting song file", error);
      }
    }
  };

  const deleteSongsBulk = async (ids: string[]) => {
    const remaining = playlist.filter(s => !ids.includes(s.id));
    const deleted = playlist.filter(s => ids.includes(s.id));

    for (const song of deleted) {
      try {
        await FileSystem.deleteAsync(song.uri, { idempotent: true });
      } catch (error) {
        console.error("Error deleting song file", error);
      }
    }

    setPlaylist(remaining);
    await savePlaylist(remaining);

    const updatedCustom = customPlaylists.map(cp => ({
      ...cp,
      songIds: cp.songIds.filter(sid => !ids.includes(sid))
    }));
    setCustomPlaylists(updatedCustom);
    await saveCustomPlaylists(updatedCustom);

    if (currentSong && ids.includes(currentSong.id)) {
      if (sound) await sound.unloadAsync();
      setCurrentSong(null);
      setIsPlaying(false);
    }
  };

  const toggleFavorite = async (id: string) => {
    const updatedPlaylist = playlist.map(s => 
      s.id === id ? { ...s, isFavorite: !s.isFavorite } : s
    );
    setPlaylist(updatedPlaylist);
    await savePlaylist(updatedPlaylist);
    if (currentSong?.id === id) {
      setCurrentSong({ ...currentSong, isFavorite: !currentSong.isFavorite });
    }
  };

  const setFavoritesBulk = async (ids: string[], status: boolean) => {
    const updatedPlaylist = playlist.map(s => 
      ids.includes(s.id) ? { ...s, isFavorite: status } : s
    );
    setPlaylist(updatedPlaylist);
    await savePlaylist(updatedPlaylist);
    if (currentSong && ids.includes(currentSong.id)) {
      setCurrentSong({ ...currentSong, isFavorite: status });
    }
  };

  const toggleShuffle = () => setIsShuffle(!isShuffle);

  const toggleRepeat = () => {
    const modes: RepeatMode[] = ["none", "all", "one"];
    const nextMode = modes[(modes.indexOf(repeatMode) + 1) % modes.length];
    setRepeatMode(nextMode);
  };

  const seek = async (position: number) => {
    if (sound) {
      await sound.setPositionAsync(position);
    }
  };

  const createCustomPlaylist = async (name: string, songIds: string[]) => {
    const newPlaylist: CustomPlaylist = {
      id: Math.random().toString(36).substr(2, 9),
      name,
      songIds
    };
    const updated = [...customPlaylists, newPlaylist];
    setCustomPlaylists(updated);
    await saveCustomPlaylists(updated);
  };

  const deleteCustomPlaylist = async (id: string) => {
    const updated = customPlaylists.filter(cp => cp.id !== id);
    setCustomPlaylists(updated);
    await saveCustomPlaylists(updated);
  };

  const reorderSongs = async (oldIndex: number, newIndex: number) => {
    const updated = [...playlist];
    const [moved] = updated.splice(oldIndex, 1);
    updated.splice(newIndex, 0, moved);
    setPlaylist(updated);
    await savePlaylist(updated);
    if (currentQueue === playlist) {
      setCurrentQueue(updated);
    }
  };

  const updatePlaylistOrder = async (newPlaylist: Song[]) => {
    setPlaylist(newPlaylist);
    await savePlaylist(newPlaylist);
    if (currentQueue === playlist) {
      setCurrentQueue(newPlaylist);
    }
  };

  return (
    <AudioContext.Provider value={{
      playlist,
      customPlaylists,
      currentSong,
      isPlaying,
      playbackStatus,
      isShuffle,
      repeatMode,
      importSongs,
      playSong,
      pauseSong,
      resumeSong,
      nextSong,
      previousSong,
      deleteSong,
      deleteSongsBulk,
      toggleFavorite,
      setFavoritesBulk,
      toggleShuffle,
      toggleRepeat,
      seek,
      createCustomPlaylist,
      deleteCustomPlaylist,
      reorderSongs,
      updatePlaylistOrder
    }}>
      {children}
    </AudioContext.Provider>
  );
};

export const useAudio = () => {
  const context = useContext(AudioContext);
  if (!context) {
    throw new Error("useAudio must be used within an AudioProvider");
  }
  return context;
};

